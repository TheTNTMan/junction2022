class settings:
    verbose = False
    distance = 0.3